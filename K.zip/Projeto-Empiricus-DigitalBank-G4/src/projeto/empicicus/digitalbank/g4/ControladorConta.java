package projeto.empicicus.digitalbank.g4;

public interface ControladorConta {

	//Autor Thiago Da Silva Barbosa Camelo

	public abstract void debitado(float valor);
}
